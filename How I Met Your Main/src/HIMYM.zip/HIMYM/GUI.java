package HIMYM;

public class GUI {

}
