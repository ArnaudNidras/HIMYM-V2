package HIMYM;

public class Player {

	private String name;
	private Guild guild;
	private Faction faction;
	private Class classe;
	private Specialization specialization;
	private int nbGotKilled;
	private int nbKilled;
	private int hpLeft;
	private WhispRage whisprage;
	private int skill;
	private boolean backped;

	public Player(String name, Guild guild, Faction faction, Class classe, Specialization specialization, int hpLeft,
			int quality, String comment, int skill, boolean backped) {

		this.name = name;
		this.guild = guild;
		this.faction = faction;
		this.classe = classe;
		this.specialization = specialization;
		this.nbGotKilled = 0;
		this.nbKilled = 0;
		this.hpLeft = hpLeft;
		this.whisprage = new WhispRage(quality, comment);
		this.skill = skill;
		this.backped = backped;

	}

	public String GetName() {

		return name;

	}

	public Guild GetGuild() {

		return guild;

	}

	public Faction GetFaction() {

		return faction;

	}

	public Class GetClass() {

		return classe;

	}

	public Specialization GetSpecialization() {

		return specialization;

	}

	public int getGotKilled() {

		return nbGotKilled;

	}

	public int getKilled() {

		return nbKilled;

	}

	public void gotKilled() {

		nbGotKilled++;

	}

	public void killed() {

		nbKilled++;

	}

	public void setHPLeft(int hpLeft) {

		this.hpLeft = hpLeft;

	}

	public int getHPLeft() {

		return hpLeft;

	}

	public WhispRage getWhispRage() {

		return whisprage;

	}

	public void setSkill(int skill) {

		this.skill = skill;

	}

	public void setBackped(boolean backped) {

		this.backped = backped;

	}

	public int getSkill() {

		return skill;

	}

	public boolean getBackped() {

		return backped;

	}

}
