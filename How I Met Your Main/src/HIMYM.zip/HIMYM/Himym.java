package HIMYM;

public class Himym {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
