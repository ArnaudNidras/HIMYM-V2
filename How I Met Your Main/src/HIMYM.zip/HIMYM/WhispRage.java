package HIMYM;

public class WhispRage {
	
	private int nb;
	private int quality;
	private String comment = "";
	//lien fichier jpeg � faire plus tard;
	
	public WhispRage(int quality, String comment){
		
		this.nb = 1;
		this.quality = quality;
		this.comment = comment;
		
	}
	
	public void addNB(){
		
		nb ++;
		
	}
	
	public void setQuality(int quality){
		
		this.quality = quality;
		
	}
	
	public void addComment(String comment){
		
		this.comment += "/nNew comment : " + comment;
		
	}
	
	public int getNB(){
		
		return nb;
		
	}

	public int getQuality(){
		
		return quality;
		
	}
	
	public String getComment(){
		
		return comment;
		
	}
	
}
