package HIMYM;

public class Fight {
	
	private Player a;
	private Player b;
	private Player winner;
	private Player loser;
	
	private Time time;
	private Place place;
	
	public Fight(Player a, Player b, Player winner, Player loser, Time time, Place place){
		
		this.a = a;
		this.b = b;
		this.winner = winner;
		this.loser = loser;
		this.time = time;
		this.place = place;
		
	}
	
	public Player getPlayerA(){
		
		return a;
		
	}
	
	public Player getPlayerB(){
		
		return b;
		
	}
	
	public Time getTime(){
		
		return time;
		
	}
	
	public Place getPlace(){
		
		return place;
		
	}
	
	public Player getWinner(){
		
		return winner;
		
	}
	
	public Player getLoser(){
		
		return loser;
		
	}

}
